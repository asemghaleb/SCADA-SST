/*
 * ModbusFace.h
 */

#ifndef ModbusFace_H_
#define ModbusFace_H_
#include "modbus.h"
#include <sys/types.h>
#include <sys/socket.h>
#include "SST_Face.h"
#include <pthread.h>
#include <sys/ioctl.h>
#include <netinet/in.h>
#include <netinet/ip.h>
#include <netinet/tcp.h>
#include <arpa/inet.h>
#include <termios.h>
#include <omnetpp.h>

class ModbusFace: public cSimpleModule,public SST_Face {
	
private:
	int socket_conn;
	modbus_param_t mb_param;
	modbus_mapping_t mb_mapping;

	void listen();


protected:
	virtual void execute(void * arg_);
//    virtual void initialize();
//    virtual void handleMessage(cMessage *msg);

public:
	ModbusFace();
	ModbusFace(const char * p_host,int p_port);
	virtual ~ModbusFace();
	virtual void processMessage(ssMsg *msg);
	virtual void Open();
	virtual void Close();

};

#endif /* ModbusFace_H_ */
