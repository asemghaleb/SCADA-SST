//  SST_Scheduler_old.h
//  RTScheduler


#ifndef SST_Scheduler_old_H_
#define SST_Scheduler_old_H_
#include <sys/time.h>
#include <string>
#include <vector>
#include <iostream>
#include "SST_Face.h"
#include "ModbusFace.h"
#include <omnetpp.h>

using namespace std;

class SST_Scheduler_old : public cScheduler{
	
private:
	//vector<SST_Face *> faces;
	timeval baseTime;
    virtual void setupConnector();
//    virtual bool receiveWithTimeout(long usec);
    virtual int receiveUntil(const timeval& targetTime);
	
public:
    vector<SST_Face *> faces;
	SST_Scheduler_old();
	virtual ~SST_Scheduler_old();
	
	/**
	 * Called at the beginning of a simulation run.
	 */
	virtual void startRun();
	
	/**
	 * Called at the end of a simulation run.
	 */
	virtual void endRun();
	
	/**
	 * Recalculates "base time" from current wall clock time.
	 */
	virtual void executionResumed();
	
	/**
	 * To be called from the module which wishes to receive data from the
	 * socket. The method must be called from the module's initialize()
	 * function.
	 */
	//	    virtual void setInterfaceModule(cModule *module, cMessage *notificationMsg,
	//	                                    uint8_t *recvBuffer, int recvBufferSize, int *numBytesPtr);
	
	/**
	 * Scheduler function -- it comes from cScheduler interface.
	 */
	virtual cMessage *getNextEvent();
	
	/**
	 * Send on the currently open connection
	 */
	//virtual void sendBytes(uint8_t * buf, size_t numBytes);
	
	virtual SST_Face *getGateway(int gateType);
	virtual timeval getBaseTime();
};

#endif /* SST_Scheduler_old_H_ */

