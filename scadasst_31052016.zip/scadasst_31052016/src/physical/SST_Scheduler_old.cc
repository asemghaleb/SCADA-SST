//
//  SST_Scheduler_old.cpp
//  RTScheduler
//
//

#include "SST_Scheduler_old.h"

Register_Class(SST_Scheduler_old)
;

SST_Scheduler_old::SST_Scheduler_old() {

}

SST_Scheduler_old::~SST_Scheduler_old() {
	// TODO Auto-generated destructor stub
}

void SST_Scheduler_old::startRun() {

    // TODO Asem: create loop her that reads faces
    //that should be created from omnetpp.ini and pass to ModbusFacee constructor
    // the port number on which the created face should listen
    // the index of retrieving faces from the faces stack in the order of creating
    // the faces according to the order of listing them in omnetpp.ini parameter

    // ModbusFace *face;
	//face = new ModbusFace("localhost",503);
	//ModbusFace *face1;
	//face1 = new ModbusFace("localhost",504);
	//faces.push_back(face);
	//faces.push_back(face1);
	gettimeofday(&baseTime, NULL);
	cout << "SST_Scheduler_old started at " << baseTime.tv_sec << endl;
	setupConnector();
}

void SST_Scheduler_old::setupConnector() {
	vector<SST_Face *>::iterator iter;
	for (iter = faces.begin(); iter != faces.end(); ++iter) {
		(*iter)->Open();
	}

}

void SST_Scheduler_old::executionResumed() {
	gettimeofday(&baseTime, NULL);
	baseTime = timeval_substract(baseTime, SIMTIME_DBL(simTime()));
}

void SST_Scheduler_old::endRun() {
	vector<SST_Face *>::iterator iter;
	for (iter = faces.begin(); iter != faces.end(); ++iter) {
		(*iter)->Close();
		delete (*iter);
	}

}

timeval SST_Scheduler_old::getBaseTime() {
	return baseTime;
}

int SST_Scheduler_old::receiveUntil(const timeval& targetTime) {
	// if there's more than 200ms to wait, wait in 100ms chunks
	// in order to keep UI responsiveness by invoking ev.idle()
	timeval curTime;
	gettimeofday(&curTime, NULL);
	while (targetTime.tv_sec - curTime.tv_sec >= 2 || timeval_diff_usec(targetTime, curTime) >= 200000) {
		vector<SST_Face *>::iterator iter;
		for (iter = faces.begin(); iter != faces.end(); ++iter) {
			int retcode =(*iter)->nextMessage(100); //100 ms
			if (retcode == 0)
				return 1;
		}
		if (ev.idle())
			return -1;
		gettimeofday(&curTime, NULL);
	}

	// difference is now at most 100ms, do it at once
	long usec = timeval_diff_usec(targetTime, curTime);
	if (usec > 0) {
		vector<SST_Face *>::iterator iter;
		for (iter = faces.begin(); iter != faces.end(); ++iter) {
			if((*iter)->nextMessage(usec) == 0);
				return 1;
		}
	}
	return 0;
}

/*cMessage *SST_Scheduler_old::getNextEvent() {
	//cout << "getNextEvent" << endl;
	//assert that we've been configured
	if (faces.size() == 0)
		throw cRuntimeError(
				"SST_Scheduler_old: setFace() not called: it must be called from a module's initialize() function");

	//	// calculate target time
	timeval targetTime;
	cMessage *msg = sim->msgQueue.peekFirst();
	if (!msg) {
		// if there are no events, wait until something comes from outside
		// TBD: obey simtimelimit, cpu-time-limit
		targetTime.tv_sec = LONG_MAX;
		targetTime.tv_usec = 0;
	} else {
		// use time of next event
		simtime_t eventSimtime = msg->getArrivalTime();
		targetTime = timeval_add(baseTime, eventSimtime.dbl());
	}
	//cout << "getting here" << endl;
	//
	// if needed, wait until that time arrives
	timeval curTime;
	gettimeofday(&curTime, NULL);
	if (timeval_greater(targetTime, curTime)) {
		int status = receiveUntil(targetTime);
		if (status == -1)
			return NULL; // interrupted by user
		if (status == 1)
			msg = sim->msgQueue.peekFirst(); // received something
	} else {
		// we're behind -- customized versions of this class may
		// alert if we're too much behind, whatever that means
		cout << "------ very behind -----" << endl;
	}

	// ok, return the message
	return msg;
}
*/

cMessage *SST_Scheduler_old::getNextEvent()
{
    cMessage *msg = sim->msgQueue.peekFirst();
    if (!msg)
        throw cTerminationException(eENDEDOK);
    return msg;
}

SST_Face *SST_Scheduler_old::getGateway(int gateType) {
	return faces[gateType];
}

