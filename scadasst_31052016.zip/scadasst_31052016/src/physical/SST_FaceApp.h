
#ifndef SST_FaceApp_H_
#define SST_FaceApp_H_
#include <omnetpp.h>


class SST_Face;

class SST_FaceApp : public cSimpleModule{

private:
	SST_Face *face;
	cMessage *notificationMsg;
	const char *extAddress;
	int      port;

protected:
    virtual void initialize();
    virtual void handleMessage(cMessage *msg);

public:
	SST_FaceApp();
	virtual ~SST_FaceApp();
	
	virtual void setGate(SST_Face *face);
	virtual cMessage * getNotificationMsg();
	const char * getExtAddress();
};

#endif /* SST_FaceApp_H_ */
