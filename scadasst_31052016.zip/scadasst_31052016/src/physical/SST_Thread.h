#ifndef SST_THREAD_H_
#define SST_THREAD_H_
#include <pthread.h>
#include <sys/time.h>
#include <iostream>

using namespace std;

class SST_Thread  {

private:
	void * arg_;
	pthread_t thread;
	pthread_cond_t cond;
	pthread_mutex_t mutex;


protected:
	bool nextMsg;
	void run(void * arg);
	static void * entryPoint(void*);
	virtual void setup();
	virtual void execute(void*);
	int lock();
	int unlock();
	void * arg() const {
		return arg_;
	}
	void arg(void* a) {
		arg_ = a;
	}
public:
	SST_Thread();
	virtual ~SST_Thread();
	int start(void * arg_);
	int join();
	int wait();
	int wait(long ms);
	int notify();

};

#endif /* SST_THREAD_H_ */
