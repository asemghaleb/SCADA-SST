
#ifndef SST_Face_H_
#define SST_Face_H_
class SST_Scheduler;
#include <vector>
#include "SST_FaceApp.h"
#include "SST_Thread.h"
#include <iostream>
using namespace std;

#include <omnetpp.h>
struct ssMsg {
	void * payload;
	char * extAddress;
};

class SST_Face: public SST_Thread {

private:

    SST_Scheduler *scheduler;

protected:
	int port;

	vector<SST_FaceApp *> faceappes;
	SST_FaceApp *getfaceappDestination(const char * extAddress);
public:

	SST_Face();

	virtual ~SST_Face();

	virtual void faceappBinding(SST_FaceApp *faceapp);

	virtual void Open() = 0;

	virtual void Close() = 0;
	virtual void processMessage(ssMsg *msg,cModule *mod1);

	void nextMessage();
	int nextMessage(long ms);
};

#endif /* SST_Face_H_ */
