#include "SST_Scheduler.h"
#include "IPControlInfo.h"
#include "SST_Face.h"

SST_Face::SST_Face() {
	cout << "Hi face" << endl;
	scheduler = check_and_cast<SST_Scheduler *> (simulation.getScheduler());
}

SST_Face::~SST_Face() {
	cout << "Bye face" << endl;
}

SST_FaceApp *SST_Face::getfaceappDestination(const char * extAddress) {
	vector<SST_FaceApp *>::iterator iter;

	for (iter = faceappes.begin(); iter != faceappes.end(); ++iter) {

		const char * extAddr = (*iter)->getExtAddress();
		if (strcmp(extAddr, extAddress) == 0) {
		    return *iter;
		}
	}
	return NULL;
}

int SST_Face::nextMessage(long ms) {

	SST_Thread::lock();
	int retcode;
	if (!nextMsg) {
		retcode = SST_Thread::wait(ms);
	}

	nextMsg = false;
	SST_Thread::notify();
	SST_Thread::unlock();
	return retcode;
}
void SST_Face::nextMessage() {
	SST_Thread::lock();
	if (!nextMsg) {
		SST_Thread::wait();
	}
	nextMsg = false;
	SST_Thread::notify();
	SST_Thread::unlock();
}

void SST_Face::faceappBinding(SST_FaceApp *faceapp) {
	faceappes.push_back(faceapp);
	cout << "faceapp added" << endl;
}

void SST_Face::processMessage(ssMsg *msg,cModule *mod1) {
	//	else
//	    cout<<"No faceapp found initialized with ip: "<<msg->extAddress<<endl;
	SST_Thread::unlock();
	// TBD assert that it's somehow not smaller than previous event's time
	//	notificationMsg->setArrival(module, -1, t);
	//	simulation.msgQueue.insert(notificationMsg);
}
