
#include "SST_Scheduler.h"
#include "SST_FaceApp.h"
Define_Module(SST_FaceApp);

SST_FaceApp::SST_FaceApp() {

}

SST_FaceApp::~SST_FaceApp() {
	// TODO Auto-generated destructor stub
}

void SST_FaceApp::initialize(){
	extAddress = par("extAddress");
	port = par("port");
	// TODO Asem: Add another parameter that hold the face number to be used to
	// access faces in the faces stack
	 ModbusFace *face1;
	 face1 = new ModbusFace("localhost",port);
	 face1->Open();
	 //faces.push_back(face);
	notificationMsg = new cMessage(extAddress);
    SST_Scheduler *sst_Scheduler = check_and_cast<SST_Scheduler *> (simulation.getScheduler());
    sst_Scheduler->faces.push_back(face1);
	face = sst_Scheduler->getFace(0);
	face->faceappBinding(this);
}

const char * SST_FaceApp::getExtAddress(){
	return extAddress;
}
void SST_FaceApp::setGate(SST_Face *face){
	this->face = face;
}

cMessage * SST_FaceApp::getNotificationMsg(){
	return notificationMsg;
}

void SST_FaceApp::handleMessage(cMessage *msg){

	if(msg==notificationMsg){
	    cModule *dest=msg->getSenderModule();
	    int tt=msg->getSenderModuleId();
	    if (dest != NULL) {
	        cout<<"dest is not null"<<endl;
        cMessage *msg0 = new cMessage("sender");
	    timeval curTime;
	    gettimeofday(&curTime, NULL);
//	    curTime = timeval_substract(curTime,cScheduler->curTime);
	    simtime_t t = curTime.tv_sec + curTime.tv_usec * 1e-6;
	    msg0->setArrival(dest,-1, t);
		send(msg0,"out");
        cout<<"Notification Message after send"<<endl;
	    }
	}else{
		cout << "msg received from : " << msg << endl;
		delete msg;
	}
}

