// SST_Thread.cpp

#include "SST_Thread.h"

SST_Thread::SST_Thread() {

}

SST_Thread::~SST_Thread() {
	// TODO Auto-generated destructor stub
}

int SST_Thread::start(void * arg_) {
	arg(arg_);

	int code = pthread_create(&thread, 0, &SST_Thread::entryPoint, this);

	return code;
}

void SST_Thread::run(void * arg_) {
	setup();
	execute(arg_);
}

/*static */
void * SST_Thread::entryPoint(void * pthis) {
	SST_Thread * pt = (SST_Thread*) pthis;
	pt->run(pt->arg());
	return NULL;
}

int SST_Thread::wait() {
	return pthread_cond_wait(&cond, &mutex);
}

int SST_Thread::wait(long ms) {
	timeval now;
	timespec timeout;
	gettimeofday(&now, NULL);
	TIMEVAL_TO_TIMESPEC(&now, &timeout);
	if (ms > 1000) {
		timeout.tv_sec = timeout.tv_sec + (ms / 1000);
		timeout.tv_nsec = timeout.tv_nsec  + ((ms % 1000) * 1000000);
	} else{
		timeout.tv_nsec = timeout.tv_nsec + (ms * 1000000);
	}
	return pthread_cond_timedwait(&cond, &mutex, &timeout);
}

int SST_Thread::notify() {
	return pthread_cond_signal(&cond);
}

int SST_Thread::lock() {
	return pthread_mutex_lock(&mutex);
}
int SST_Thread::unlock() {
	return pthread_mutex_unlock(&mutex);
}

void SST_Thread::setup() {
	nextMsg = false;
	if (pthread_mutex_init(&mutex, NULL) != 0) {
		cout << "error initialising mutex" << endl;
	}
	if (pthread_cond_init(&cond, NULL) != 0) {
		cout << "error initialising cond" << endl;
	}

}

void SST_Thread::execute(void* arg) {
	// Your code goes here
}

int SST_Thread::join() {
	return pthread_join(thread, NULL);
}
